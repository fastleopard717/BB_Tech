const NodeMediaServer = require('.');

const isWin = process.platform === 'win32';

const config = {
  logType: 3,

  rtmp: {
    port: 1935,
    chunk_size: 60000,
    gop_cache: true,
    ping: 30,
    ping_timeout: 60,
  },

  http: {
    port: 8000,
    mediaroot: './media',
    allow_origin: '*',
  },

  // FFmpeg-based remux to HLS/DASH (DASH produces index.mpd)
  trans: {
    ffmpeg: isWin ? '.\\ffmpeg\\bin\\ffmpeg.exe' : '/usr/bin/ffmpeg',
    tasks: [
      {
        app: 'live',
        hls: true,
        hlsFlags: '[hls_time=2:hls_list_size=3:hls_flags=delete_segments]',
        dash: true,
        dashFlags: '[f=dash:window_size=3:extra_window_size=5]',
      },
    ],
  },

  // Built-in signed URL auth (publish + play)
  auth: {
    play: true,
    publish: true,
    secret: 'CHANGE_ME_SUPER_SECRET',
  },
};

const nms = new NodeMediaServer(config);

// Hooks for your own auth/source management (reject invalid publish/play)
nms.on('prePublish', (id, StreamPath, args) => {
  console.log('[prePublish]', id, StreamPath, args);
  // Example:
  // const session = nms.getSession(id);
  // if (!isValidPublisher(args)) session.reject();
});

nms.on('prePlay', (id, StreamPath, args) => {
  console.log('[prePlay]', id, StreamPath, args);
  // Example:
  // const session = nms.getSession(id);
  // if (!isValidViewer(args)) session.reject();
});

nms.run();